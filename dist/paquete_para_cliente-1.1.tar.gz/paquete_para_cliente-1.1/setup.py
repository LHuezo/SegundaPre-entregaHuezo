from setuptools import setup

setup(
    name="Paquete_Para_Cliente",
    version="1.1",
    description="Creo un paquete para modelar la clase clinte",
    author="Lautaro Huezo",
    author_email="lautarohuezo9@gmail.com"
)